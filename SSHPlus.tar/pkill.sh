#!/bin/bash
user=$1
sleep 1.5
pkill -u $user
